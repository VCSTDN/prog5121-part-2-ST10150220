import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 * Login System with Registration and Post-Login Menu
 * Author: ST10150220
 */
public class Login {
    private Map<String, String> registeredUsers;

    public static void main(String[] args) {
        Login login = new Login();

        OUTER:
        while (true) {
            Object[] options = {"Login", "Register", "Exit"};
            int choice = JOptionPane.showOptionDialog(null, "Would you like to Login or Register?", "Login or Register", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            switch (choice) {
                case JOptionPane.YES_OPTION: {
                    String uName = JOptionPane.showInputDialog(null, "Please Enter Your Username");
                    String password = JOptionPane.showInputDialog(null, "Please Enter Password");
                    String loginStatus = login.returnLoginStatus(uName, password);
                    JOptionPane.showMessageDialog(null, loginStatus);

                    if (login.loginUser(uName, password)) {
                        login.menu();
                    }
                    break;
                }
                case JOptionPane.NO_OPTION: {
                    String fName = JOptionPane.showInputDialog(null, "Please Enter Your First Name");
                    String lName = JOptionPane.showInputDialog(null, "Please Enter Your Last Name");
                    String uName = JOptionPane.showInputDialog(null, "Please Enter Your Username");
                    String password = JOptionPane.showInputDialog(null, "Please Enter a Password");
                    String registrationMessage = login.registerUser(fName, lName, uName, password);
                    JOptionPane.showMessageDialog(null, registrationMessage);
                    break;
                }
                case JOptionPane.CANCEL_OPTION:
                case JOptionPane.CLOSED_OPTION:
                    break OUTER;
                default:
                    break;
            }
        }
    }

    public Login() {
        this.registeredUsers = new HashMap<>();
    }

    public String registerUser(String fName, String lName, String uName, String password) {
        if (!checkUserName(uName))
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";

        if (!checkPassword(password))
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";

        registeredUsers.put(uName, password);
        return "Welcome " + fName + " " + lName + ", it is great to see you.";
    }

    public boolean loginUser(String uName, String password) {
        return registeredUsers.containsKey(uName) && registeredUsers.get(uName).equals(password);
    }

    public String returnLoginStatus(String uName, String password) {
        if (loginUser(uName, password))
            return "Welcome to EasyKanban";
        else
            return "Login failed. Please check Username or Password";
    }

    public boolean checkUserName(String uName) {
        return uName.contains("_") && uName.length() <= 5;
    }

    public boolean checkPassword(String password) {
        if (password.length() < 8)
            return false;

        boolean upperCase = false;
        boolean digit = false;
        boolean specialChar = false;
        boolean lowerCase = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c))
                upperCase = true;
            else if (Character.isDigit(c))
                digit = true;
            else if (!Character.isLetterOrDigit(c))
                specialChar = true;
            else if (Character.isLowerCase(c))
                lowerCase = true;
        }
        return upperCase && digit && specialChar && lowerCase;
    }

    public void menu() {
        boolean continueMenu = true;
        while (continueMenu) {
            String[] options = {"Add Task", "Show Report", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Please enter your choice:", "Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0:
                    String taskAmntStr = JOptionPane.showInputDialog(null, "How many tasks would you like to add?");
                    int taskAmnt;
                    try{
                        taskAmnt = Integer.parseInt(taskAmntStr);
                        addTask(taskAmnt);
                    }
                    catch(NumberFormatException e){
                        JOptionPane.showMessageDialog(null, "Error. Please Enter a Valid number");
                    }
                    break;
                case 1:
                    JOptionPane.showMessageDialog(null, "Coming Soon");
                    break;
                case 2:
                    continueMenu = false;
                    break;
                default:
                    continueMenu = false;
                    break;
            }
        }
    }
    public void addTask(int taskAmnt){
         for (int i = 0; i < taskAmnt; i++) {
            String taskName = JOptionPane.showInputDialog(null, "Enter the name of task " + (i + 1) + ":");
            String taskDescription;
            while (true) {
                taskDescription = JOptionPane.showInputDialog(null, "Enter the description of task " + (i + 1) + " (max 50 characters):");
                if (taskDescription.length() <= 50) {
                    System.out.println("Task Captured");
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Description must be less than 50 characters");
                }
            }
            String assignedDevFirstName = JOptionPane.showInputDialog(null, "Enter the first name of the developer assigned to task " + (i + 1) + ":");
            String assignedDevLastName = JOptionPane.showInputDialog(null, "Enter the last name of the developer assigned to task " + (i + 1) + ":");
    }
}
}